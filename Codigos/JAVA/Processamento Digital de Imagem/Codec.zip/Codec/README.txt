Para a execução do programa vá até o arquivo .jar (Codec/classes/artifacts/Codec_jar)
execute o comando 

 $ java -jar Codec.jar

o programa irá pedir o diretório da imagem.

A imagem final aparecerá na mesma pasta do arquivo .jar

Obs.: Caso indique erro de estouro de pilha, execute a aplicação com o comando
	
	$ java -Xmx2G -jar Codec.jar

adicionando 2 Gigas de memoria RAM à aplicação.