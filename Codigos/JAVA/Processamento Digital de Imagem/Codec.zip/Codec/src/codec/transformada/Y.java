package codec.transformada;

public class Y {
    private int y;

    public Y (){
        this.y = 0;
    }
    public Y (int y){
        this.y = y;
    }

    public int getY() {
        return y;
    }
    public void setY(int y) {
        this.y = y;
    }
}
