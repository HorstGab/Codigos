package codec.transformada;

public class Cr {

    private int cr;

    public Cr (){
        this.cr = 0;
    }
    public Cr (int cr){
        this.cr = cr;
    }

    public int getCr() {
        return cr;
    }
    public void setCr(int cr) {
        this.cr = cr;
    }
}
