package codec.transformada;

public class Cb {

    private int cb;

    public Cb (){
        this.cb = 0;
    }
    public Cb (int cb){
        this.cb = cb;
    }

    public int getCb() {
        return cb;
    }
    public void setCb(int cb) {
        this.cb = cb;
    }
}
