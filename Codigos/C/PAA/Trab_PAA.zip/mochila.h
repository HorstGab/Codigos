#ifndef MOCHILA_H
#define MOCHILA_H

#include <stdio.h>
#include <stdlib.h>

//
//Entrada:
//Retorno:
//Pré-Condições:
//Pós-Condições:
int max(int a, int b);

//
//Entrada:
//Retorno:
//Pré-Condições:
//Pós-Condições:
void imprimir(int m[][50]);

//
//Entrada:
//Retorno:
//Pré-Condições:
//Pós-Condições:
int knapSackPD (int w);

//
//Entrada:
//Retorno:
//Pré-Condições:
//Pós-Condições:
void loadData();

#endif